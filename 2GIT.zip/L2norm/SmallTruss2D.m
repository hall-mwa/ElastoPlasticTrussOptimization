

NODE=[  0 0 0
        1 0 0
        2 0 0 
        3 0 0 
        4 0 0
        0 1 0
        1 1 0
        2 1 0
        3 1 0];

Dof=[ 1 2 3
      4 5 6
      7 8 9
      10 11 12
      13 14 15
      16 17 18
      19 20 21
      22 23 24
      25 26 27];            

  if 1==0
Edof=[1 1 2 3 4 5 6
      2 4 5 6 7 8 9
      3 7 8 9 10 11 12
      4 10 11 12 13 14 15
      5 4 5 6 16 17 18
      6 4 5 6 19 20 21
      7 19 20 21 7 8 9
      8 7 8 9 22 23 24
      9 10 11 12 22 23 24
      10 10 11 12 25 26 27
      11 13 14 15 25 26 27];
  end
InPlanebc=[1 2 3  16 17 18]';
bc(:,1)=[InPlanebc; (3:3:length(Dof(:,1))*3)'];
bc(:,2)=0;
nen=2;




BARS=[1   2
      2   3
      3   4 
      4   5
      6   2
      7   2
      7   3
      8   3
      8   4
      9   4
      9   5
      6   7
      7   8
      8   9 
      1   7
     2   8
     3   9
      9   1
      8   1
   6   4
      7 4
     5 8
      ] ;

Loaddofs=14;


ELCOORD=[NODE(BARS(:,1),1)  NODE(BARS(:,2),1)  NODE(BARS(:,1),2)  NODE(BARS(:,2),2)  NODE(BARS(:,1),3)  NODE(BARS(:,2),3)];


TC     = [BARS(:,1)*3-2 BARS(:,1)*3-1 BARS(:,1)*3 ...
          BARS(:,2)*3-2 BARS(:,2)*3-1 BARS(:,2)*3];        % Table of connectivity, dofs

Lengths=BarLengths(ELCOORD);
ELCOORD(:,7)=Lengths';      % Store bar lengths in last column in coordinate matrix    

nISV=4;                   % Number of internal state variables
nelm=length(BARS(:,1));   % Number of elements
Nnode=length(NODE(:,1));  % Number of nodes
ndof=3*Nnode;             % Number of degrees of freedom

Cutoff=0.00;
first_dlambda=0.005;   
delta0=5e-2;  
V_max=10e88;
