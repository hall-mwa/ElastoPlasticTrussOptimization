

nelm=length(BARS(:,1));
Nnode=length(NODE(:,1));
ndof=3*Nnode;

Edof = [BARS(:,1)*3-2 BARS(:,1)*3-1 BARS(:,1)*3 BARS(:,2)*3-2 BARS(:,2)*3-1 BARS(:,2)*3];

bc = GetSupports3(SUPP);
bc(:,2)  = zeros(length(bc),1);

ELCOORD=[NODE(BARS(:,1),1)  NODE(BARS(:,2),1)  NODE(BARS(:,1),2)  NODE(BARS(:,2),2)  NODE(BARS(:,1),3)  NODE(BARS(:,2),3)];

Loaddofs=LOAD(:,1)*3-2;

save('Coarse2Beam.mat', 'BARS',  'ELCOORD',  'Loaddofs',  'NODE','bc')
