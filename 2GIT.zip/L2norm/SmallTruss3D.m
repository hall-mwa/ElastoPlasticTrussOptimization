

NODE=[  0 0 0       %1
        1 0 0	    %2
        2 0 0       %3
        3 0 0       %4
        4 0 0       %5
        0 1 0       %6
        1 1 0       %7
        2 1 0       %8
        3 1 0       %9
        4 1 0];     %10

OneLayerNodes=length(NODE(:,1));

NODE=[NODE;NODE(1:OneLayerNodes,1:2),  NODE(1:OneLayerNodes,3)+1]; % Add another layer of nodes


BARS=[1   2
      2   3
      3   4 
      4   5
      6   2
      7   2
      7   3
      8   3
      8   4
      9   4
      9   5
      10  5
      6   7
      7   8
      8   9
      9   10] ;

BARS=[BARS;BARS+OneLayerNodes]; % Add layer 2
BARS=[BARS;[(1:OneLayerNodes);(OneLayerNodes+1:2*OneLayerNodes)]'];
for I=0:3
  BARS=[BARS; 1+I, 1+I+5+OneLayerNodes];
  BARS=[BARS; 1+I, 1+I+5+1+OneLayerNodes];
  BARS=[BARS; 1+I, 1+1+I+OneLayerNodes];
  BARS=[BARS; 1+I+5+OneLayerNodes, 5+2+I];
  BARS=[BARS; 1+I+OneLayerNodes,   2+I];
 % BARS=[BARS; 6+I, 6+I+OneLayerNodes];
 % BARS=[BARS; 6+I, 6+I+1+OneLayerNodes];
end


bc=[];
node=1;
bc=[bc; 3*node; 3*node-1; 3*node-2];
node=6;
bc=[bc; 3*node; 3*node-1; 3*node-2];
node=1+OneLayerNodes;
bc=[bc; 3*node; 3*node-1; 3*node-2];
node=6+OneLayerNodes;
bc=[bc; 3*node; 3*node-1; 3*node-2];


%bc(:,1)=[InPlanebc; (3:3:length(Dof(:,1))*3)'];
bc(:,2)=0;
%nen=2;

Loaddofs=3*5-1;
%Loaddofs=[Loaddofs; 3*5-2];
Loaddofs=[Loaddofs; 3*(5+OneLayerNodes)-1];
%Loaddofs=[Loaddofs; 3*(5+OneLayerNodes)-2];

