    
    k=0;
   % xkinit=0.1*0.25*3;
    Randomize=0.0;
    Initiate;

    lambda=0;                   % Initiate load parameter
    Kt=0*Kt;    
    Fint=0*Fint;
    Residual=Fint;
    Fext=Fint;
    a=0*a;
    stress=0*stress;
    Etan=ep(1,3)*ones(nelm,1);  % Set undeformed elastic properties    
    Yold=0*Yold;                % Reset all internal state variables
    k = k+1;                    % Increment design loop counter
    
    


    Nstep=0;                    % Reset load step counter
    while lambda<(lambda_max-eps)
       Nstep=Nstep+1;           % Increment load step counter
       disp(['Starting load step: ', num2str(Nstep), ' Current twist/def.:', num2str(lambda)])
       Fint=Fint*0;
       
       Residual=0*Residual; res=3;  % Reset residual. Set res=3 to enter the equilibrium interation (while) loop           
           
       
       if Nstep==1       
           dlambda=first_dlambda;               % Initial gueass for the load increment
       end
       dlambda=min(lambda_max-lambda,dlambda);  % Make sure that the maximum load is lambda_max
       lambda=lambda+dlambda;                   % Increment load
       Iter=0;                                  % Reset equlibrium Newton iteration counter       
       while (res>10^(-9))       
          Iter=Iter+1;
          Kt=0*Kt;
          for elnr=1:nelm            % Assembly
             Kt(TC(elnr,:),TC(elnr,:)) = Kt(TC(elnr,:),TC(elnr,:))+bar3ge(xk(elnr),ELCOORD(elnr,:),a(TC(elnr,:)),stress(elnr),Etan(elnr),ep(elnr,:));                         
          end
          
          if (Iter==1)  % Enforce Dirichlet boundary conditions
               dbc=[ Loaddofs -dlambda*ones(size(Loaddofs));bc];               
          else      
                dbc(:,2)=0;   
          end                                 
          
          a=a+solveq(Kt,-Residual,dbc);   % Increment displacement field 
          Fint=0*Fint;                    % Reset internat force vector
          Timesteps(Nstep)=dlambda     ;  % Store increments
          for elnr=1:nelm
             epsnew=bar3gstr(ELCOORD(elnr,:),a(TC(elnr,:))); % Compute strain for rod elnr
             [stress(elnr),Ynew(:,elnr),Etan(elnr), Problem(elnr)]=UniStressPlast(ep(elnr,:),Yold(:,elnr),epsnew);  % State update           
             Fint(TC(elnr,:)) = Fint(TC(elnr,:))+bar3gf(xk(elnr), ELCOORD(elnr,:),a(TC(elnr,:)),stress(elnr),ep(elnr,:));   % Load assembly      
          end                    
          Residual=Fint-Fext;
          Residual(dbc(:,1))=0;  
          res=norm(Residual);    

          disp([' Load step: ', num2str(Nstep), ' dlambda: ', num2str(dlambda),  ...
              '  # Pl.El.: ' num2str(sum(Ynew(2,:)>0)),  ' Eq. iter=', num2str(Iter), ' Residual=', num2str(res)])          
          if (Iter>20 | (sum(Problem)>0))
             disp(['Restart with half step size, Iter=', num2str(Iter), ' Problem ', num2str(sum(Problem)) ])
             lambda=lambda-dlambda; % Reset load magnitude
             dlambda=dlambda/2;
             if (Nstep==1)
                 first_dlambda=first_dlambda*0.75;
             end
             disp(['Ny dlambda ', num2str(dlambda) ])
             Nstep=Nstep-1;
             restart=1;
             res=0;
          end
       end 
       if restart
           if Nstep>0
              a=Storage(Nstep).Disp;  
              stress=Storage(Nstep).stress; 
              Etan=Storage(Nstep).Etan; 
           else
              a=0*a;
              stress=0*stress;
              Etan=ep(1,3)*ones(length(stress),1);
           end
       else
         Yold=Ynew;
         Storage(Nstep).ISV=Ynew;
         Storage(Nstep).Disp=a;  
         Storage(Nstep).stress=stress; 
         Storage(Nstep).Etan=Etan; 
        
      %   Disp(Nstep)=-lambda;      
     %    Load(Nstep)=sum(Fint(Loaddofs));
         if k==1
           DispOrig(Nstep)=-lambda;      
           LoadOrig(Nstep)=sum(Fint(Loaddofs));
           NOrig=Nstep;
         end

      %   if k==k_max
      %     DispFinal(Nstep)=-lambda;      
      %     LoadFinal(Nstep)=sum(Fint(Loaddofs));
      %     NFinal=Nstep;
      %   end                      
       end      
       
       restart=0; % No restart
     end % End load step