close all
clear all
addpath ../GCMMA-MMA-code-1.5 % You need to download this from https://www.smoptit.se/
addpath ../ElementAndModel
addpath ../Grand3             % You need to download this Springer, Struct Multidisc Optim (2015) 52:1161–1184
ResultDir="../../tex/Figscrap/"
dbstop if warning



k_max=100;      % Number of optimization loops to run. There is no other stopping critera
NstepMax=20;    % Max load increments
signom=50e0;    % Yield stress
Enom=100e3;     % Young's modulus

Input='Simple'; Lcase=4; % Changing theese parameters will generate the
%Input='Fine3DStructure'; Lcase=4;   % figures in the manuscript
%Input='Coarse3DStructure'; Lcase=1;

TOLr=1e-9;
variation=0.0;

if Input=="Simple"   
    xkinit=0.3;        
    Target(1)=-0.005;  % Target value for the displacement where plasticity should be initiated 
    Target(2)=-0.04;   % Target value for the load where plasticity should be initiated            
    Target(3)=-0.04*1;   % End displacement      
    if (Lcase==1)      % Designs for dirrefernt loads are generated below  
      Target(4)=-0.04;   
    elseif (Lcase==2) 
      Target(4)=-0.08;   
    elseif (Lcase==3)
      Target(4)=-0.16;
    elseif (Lcase==4)
      Target(4)=-0.32;  
    end
       
    load SimpleGeom.mat
    delta0=1e-9
    Initiate;     
    V_max=10^99;   
    

elseif Input=="Fine3DStructure"    
    xkinit=0.03;

    Target(1)=-0.02;  % Target value for the displacement where plasticity should be initiated 
    Target(2)=-1;     % Target value for the load where plasticity should be initiated       
    Target(3)=-0.04;
    Target(4)=-1;     % Target load at end displacement      
 
    if (Lcase==1)        
      Target(4)=-1;   
    elseif (Lcase==2) 
      Target(4)=-1.2;  
    elseif (Lcase==3)
      Target(4)=-1.5;
    elseif (Lcase==4)
      Target(4)=-2;  
    end

    load BeamGeometry.mat
    delta0=1e-9
    Initiate;
    [V_max, Crap]=volume(ones(size(xk)),Lengths,ep);        
    V_max=xkinit*V_max;    

elseif Input=="Coarse3DStructure"   
    xkinit=0.1;
    Target(1)=-0.02;  % Target value for the displacement where plasticity should be initiated    
    Target(2)=-5;     % Target value for the load where plasticity should be initiated       
    Target(3)=-0.04;  % End displacement  
    Target(4)=-5;     % Target load at end dispalcement        
    load Coarse1Beam.mat  
    Randomize=0.0;  
    Initiate;
    delta0=1e-9; 
    [V_max, Crap]=volume(ones(size(xk)),Lengths,ep);
 
    if (Lcase==3)      
      V_max=xkinit*V_max*1*0.25; 
    elseif (Lcase==2) 
      V_max=xkinit*V_max*2*0.25; 
    elseif (Lcase==1)
      V_max=xkinit*V_max*3*0.25;    
    end
end
lambda_max=-Target(3);    
k = 0;       % Initiate design loop counter
restart=0;   % Flag for restart when equlibrium iteration does not converge
while  k < k_max                  % Start of optimization loop      
    lambda=0;                     % Initiate load parameter
    Kt=0*Kt;                      % Reset stiffness matrix
    a=0*a;                        % Reset nodel displacement vector 
    stress=0*stress;              % Reset stresses
    Yold=0*Yold;                  % Reset internal state variables
    Etan=Enom*ones(nelm,1);       % Set undeformed elastic properties        
    k = k+1;                      % Increment design loop counter  
    Nstep=0;                      % Reset load step counter
    while lambda<(lambda_max-eps) % Start of Equlibrium iteration
       Nstep=Nstep+1;             % Increment load step counter
       disp(['Starting load step: ', num2str(Nstep), ' Current def.:', num2str(lambda)])
       Fint=Fint*0;               % Reset internal force vector
       res=1973;                  % Set res>0 to enter the equilibrium interation (while) loop                     
       if Nstep==1       
           dlambda=first_dlambda;              % Initial load increment
       end
   
       dlambda=min(lambda_max-lambda,dlambda);  % Make sure that the maximum load is lambda_max
       lambda=lambda+dlambda;                   % Increment load
       Iter=0;                                  % Reset equlibrium Newton iteration counter       
       while (res>TOLr)       
          Iter=Iter+1;
          Kt=0*Kt;
          for elnr=1:nelm             % Assembly
             Kt(TC(elnr,:),TC(elnr,:)) = Kt(TC(elnr,:),TC(elnr,:))+bar3ge(xk(elnr),ELCOORD(elnr,:),a(TC(elnr,:)),stress(elnr),Etan(elnr),ep(elnr,:));                         
          end
          
          if (Iter==1)                % Enforce Dirichlet boundary conditions
               dbc=[ Loaddofs -dlambda*ones(size(Loaddofs));bc];               
          else      
               dbc(:,2)=0;   
          end                                 
          
          a=a+solveq(Kt,-Fint,dbc);   % Increment displacement field 
          Fint=0*Fint;                % Reset internat force vector
          LambdaInc(Nstep)=dlambda;   % Store increments
          for elnr=1:nelm
             epsnew=bar3gstr(ELCOORD(elnr,:),a(TC(elnr,:))); % Compute strain for rod elnr
             [stress(elnr),Ynew(:,elnr),Etan(elnr), Problem(elnr)]=UniStressPlast(ep(elnr,:),Yold(:,elnr),epsnew);  % State update           
             Fint(TC(elnr,:)) = Fint(TC(elnr,:))+bar3gf(xk(elnr), ELCOORD(elnr,:),a(TC(elnr,:)),stress(elnr),ep(elnr,:));   % Load assembly      
          end                   
          AppliedLoad=sum(Fint(Loaddofs));
          Fint(dbc(:,1))=0;  
          res=norm(Fint);    
     
          disp([' Load step: ', num2str(Nstep), ' Load Inc.: ', num2str(dlambda),  ...
              '  # Pl. elem.: ' num2str(sum(Ynew(2,:)>0)),  ' Eq. iter=', ...
                 num2str(Iter), ' Residual=', num2str(res)])
          NbrOfPlasticElem(k)=sum(Ynew(2,:)>0);

          if (Iter>20 | (sum(Problem)>0))
             lambda=lambda-dlambda;
             dlambda=dlambda/2;
             if (Nstep==1)
                 first_dlambda=first_dlambda*0.75;
             end
             disp(['Restart with new load. inc. ', num2str(dlambda) ])
             Nstep=Nstep-1;
             restart=1;
             res=0;
          end
       end 
       if restart
           if Nstep>0
              a=Storage(Nstep).Disp;  
              stress=Storage(Nstep).stress; 
              Etan=Storage(Nstep).Etan;    

           else
              a=0*a;
              stress=0*stress;
              Etan=ep(1,3)*ones(length(stress),1);
           end
       else
       Yold=Ynew;
       Storage(Nstep).ISV=Ynew;
       Storage(Nstep).Disp=a;  
       Storage(Nstep).stress=stress; 
       Storage(Nstep).Etan=Etan; 
        
       Disp(Nstep)=-lambda;      
       Load(Nstep)=sum(Fint(Loaddofs));
       if k==1 % Store the initial response
          DispOrig(Nstep)=-lambda;      
          LoadOrig(Nstep)=AppliedLoad;
          NOrig=Nstep;
       elseif k==k_max
          DispFinal(Nstep)=-lambda;      
          LoadFinal(Nstep)=AppliedLoad;
          NFinal=Nstep;
       end                      
     end             
     restart=0; % No restart
   end          % End load step
   
   % Cost & constraint function evaluation.
   [f0,df0dx]=plast(xk, Storage,dbc,ELCOORD, TC,ep, Nstep, LambdaInc,Target, Loaddofs);
   [Vol, Vol_sens]=volume(xk,Lengths,ep);
   f0_Storage(k) = f0;
   
   f1_vec(k) = Vol/V_max-1;
   df1dx = Vol_sens/V_max;
   
   Lk_old=Lk;
   Uk_old=Uk;
   [xmma,ymma,zmma,lam,xsi,eta,mu,zet,s,Lk,Uk] = ...
   mmasub(C,ndes,k,xk,x_min,x_max,xk_old,xk_old_old, ...
   f0_Storage(k),df0dx,f1_vec(k),df1dx,Lk,Uk,a0_mma,a_mma,c_mma,d_mma);
   scal=0.1;
   if (k>40) % Use explicit damping. In this way, the MMA parameters does not need to be modified. 
       xmma=(scal*xmma+(1-scal)*xk);
       Lk=(scal*Lk+(1-scal)*Lk_old);
       Uk=(scal*Uk+(1-scal)*Uk_old);
   end

   xk_old_old = xk_old;
   xk_old     = xk;
   xk         = xmma;
  
   DesignStorage(k,:)=xk;
   PlastStorage(k)=sum(Ynew(2,:)>0);
   
   disp(['Des.= ', num2str(k), ' completed. g0= ', num2str(f0_Storage(k)), ';   Constr. ', num2str(f1_vec(k)), ...
         ' Opt.Res.: ', num2str(norm(xk-xk_old)),         ' #pl.elmn.:', num2str(sum(Ynew(2,:)>0))]);
   if mod(k,11)
      save(['Results/DesignUpdate',num2str(k)])
   end

end
Areas=xk.*ep(:,1);

FontSize=20;
if Input=="Simple" FontSize=24; end
Magnification=100;
if Input=="Simple" Magnification=0; end
NODE1(:,1)=NODE(:,1)+a(1:3:end)*Magnification;
NODE1(:,2)=NODE(:,2)+a(2:3:end)*Magnification;
NODE1(:,3)=NODE(:,3)+a(3:3:end)*Magnification;

figure(1)
%PlotGroundStructure3(NODE1,BARS,xk,Cutoff,2,stress/signom,signom)
PlotGroundStructure3(NODE1,BARS,xk,Cutoff,2)
colorbar
filename = ResultDir+Input+num2str(Lcase)+"stress"+".eps";
view([45 25])
ax = gca; 
ax.FontSize = FontSize;    
saveas(gcf,filename,'epsc');
if Input=="Simple" 
  view(2)
else
  view([0 0])
end
filename = ResultDir+Input+num2str(Lcase)+"stress2D"+".eps";

ax = gca; 
ax.FontSize = FontSize;    
saveas(gcf,filename,'epsc');

drawnow

figure(2)
%PlotGroundStructure3(NODE1,BARS,xk,Cutoff,2,Ynew(3,:)>0,signom)

PlotGroundStructure3(NODE1,BARS,xk,Cutoff,2)

filename = ResultDir+Input+num2str(Lcase)+"plelm"+".eps";


view([45 25])
saveas(gcf,filename,'epsc');
if Input=="Simple" 
  view(2)
else
  view([0 0])
end
filename = ResultDir+Input+num2str(Lcase)+"plelm2D"+".eps";


saveas(gcf,filename,'epsc');figure(3)
if Input=="Simple"  
  plot(1:length(f0_Storage),(f0_Storage),'-*k')
  grid on
  title('Objective')
  xlabel('Iteration number')
  ylabel('g_0 [N^2]')
  ax = gca; 
  ax.FontSize = FontSize;       
else
  subplot(2,1,1);
  plot(1:length(f0_Storage),(f0_Storage),'-*k')
  grid on
  title('Objective')
  xlabel('Iteration number')
  ylabel('g_0 [N^2]')
  ax = gca;  
  ax.FontSize = FontSize; 
  subplot(2,1,2)
  plot(1:length(f1_vec),f1_vec,'-*k')
  grid on
  title('Volume constraint')
  xlabel('Iteration number')
  ylabel('g_1')
  ax = gca; 
  ax.FontSize = FontSize; 
  axis([0 length(f0_Storage) min(f1_vec) max(f1_vec)]) 
end
filename = ResultDir+Input+num2str(Lcase)+"Evo"+".eps";
saveas(gcf,filename,'epsc');

figure(3)
if Input=="Simple"  
  plot(1:length(f0_Storage),(f0_Storage/f0_Storage(1)),'-*k')
%  grid on
  title('Objective')
  xlabel('Iteration number')
  ylabel('$g_0/\tilde{g}_0$', 'Interpreter', 'latex')
%  ylabel('g_0/ bar{g}_0')
  ax = gca; 
  ax.FontSize = FontSize;       
else
  subplot(2,1,1);
  plot(1:length(f0_Storage),(f0_Storage/f0_Storage(1)),'-*k')
  grid on;
  title('Objective')
  xlabel('Iteration number')
   ylabel('$g_0/\tilde{g}_0$', 'Interpreter', 'latex')
  ax = gca;  % Volume constraint 
  ax.FontSize = FontSize; 
  subplot(2,1,2)
  plot(1:length(f1_vec),f1_vec,'-*k')
  grid on
  title('Volume constraint')
  xlabel('Iteration number')
  %ylabel('g_1')
  ylabel('$g_1$', 'Interpreter', 'latex')
  yticks([-0.6 -0.3 0])
  ax = gca; 
  ax.FontSize = FontSize; 
  axis([0 length(f0_Storage) min(f1_vec) max(f1_vec)])  
end
filename = ResultDir+Input+num2str(Lcase)+"Evo"+".eps";
saveas(gcf,filename,'epsc');


%if ~(Input=="Simple") 
%   figure(3)
%   %PlotGroundStructure3(NODE1,BARS,xk,Cutoff,2,Ynew(4,:)>0,signom)
%   view([90 0])
%end;

if (Input=="Coarse3DStructure") % Generate intial response for a design that fulfills the vol. constr.
    if (Lcase==3)              
      xkinit=1*0.25*0.1;   
    elseif (Lcase==2)    
      xkinit=2*0.25*0.1; 
    elseif (Lcase==1)        
      xkinit=3*0.25*0.1;  
    end
    
    VolResponse;
end


figure(4)
set(gca,'fontname','times') 
hold on
line([0 -Target(1) -Target(3)],[0 -Target(2) -Target(4) ],'Color','red','LineWidth',2)
plot(-[0 DispOrig(1:NOrig)],-[0 LoadOrig(1:NOrig)],'black*')
ylabel('Load [N]')
xlabel("Displacement [mm]")
if (Input=="Simple") 
    axis([0 -Target(3) 0 0.35])
elseif (Input=="Coarse")
    axis([0 0.04 0 8])
elseif (Input=="Fine3DStructure")   
    axis([0 0.04 0 2.5])
end
plot(-[0 DispFinal(1:NFinal)],-[0 LoadFinal(1:NFinal)],'blue*')
plot(-[0 DispFinal(1:NFinal)],-[0 LoadFinal(1:NFinal)],'blue')
ax = gca; 
ax.FontSize = FontSize; 
filename = ResultDir+Input+num2str(Lcase)+"response"+".eps";
saveas(gcf,filename,'epsc');




return
