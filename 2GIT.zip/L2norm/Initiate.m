Load(1:NstepMax)=0;   % Load in the point(s) where traction/non-zero displacement bounadry conditions are applied
Disp(1:NstepMax)=0;   % Displacement (abs,max) in the point(s) where traction/non-zero displacement bounadry conditions are applied
Kt=zeros(ndof);       % Initiate tangent stiffness matrix
Fint=zeros(ndof,1);   % Initiate internal force vector
Residual=Fint;        % Initiate residual force vector
Fext=Fint;            % Initiate external force vector
a=zeros(ndof,1);      % Initiate total displacement vector
stress=zeros(nelm,1); % Initiate total displacement vector


for loadstep=1:NstepMax
   Storage(loadstep).ISV=zeros(nISV,nelm);
   Storage(loadstep).Disp=zeros(ndof,1);  
   Storage(loadstep).stress=zeros(nelm,1); 
   Storage(loadstep).Etan=zeros(nelm,1); 
end

f0_vec = zeros(k_max,1); % Vector that contains the value of cost functions in the design updates
f1_vec = zeros(k_max,1); % Vector that contains the value of constraint functions in the design updates
Yold=zeros(nISV,nelm);   % Internal state variables in each integration point, here element


C = 1;                   % Number of constraints
ndes = nelm;             % Number of design variables, one per element

xk=xkinit*(1+(variation*(rand(nelm,1)-0.5))); % Initiate design variables;
xk_old     = xk;                        % Design variables in iteration iter-1
xk_old_old = xk;                        % Design variables in iteration iter-2


x_min = delta0*ones(ndes,1); % Lower bounds of design variables
x_max = ones(ndes,1);        % Upper bounds of design variables
df0dx = zeros(ndes,1);       % Gradient of f0
df1dx = zeros(C,ndes);       % Gradients of constraints
Lk = zeros(ndes,1);          % Lower asymptote
Uk = zeros(ndes,1);          % Upper asymptote
a0_mma = 1;
a_mma = zeros(C,1);
c_mma = 1d2*ones(C,1);
d_mma = 0e1*ones(C,1);    


a0_mma = 1;
a_mma = zeros(C,1);
c_mma = 1d2*ones(C,1);
d_mma = 1e0*ones(C,1);    



for elnr=1:nelm % Rod parameters. First parameter is max rod area. Here it is 10% of the rod length
   ep(elnr,:)=[(Lengths(elnr)/10)^2*pi 0.0 Enom signom Enom/100 10^99*signom/100 1 delta0 1];  %ep =[Amax nu Eo sigyo K S pen delta0 q] ;
   Etan=ep(elnr,3);
end


disp(['Number of bars: ', num2str(nelm), ' Number of nodes: ', num2str(Nnode)])


