  function [d]=solve(K,f,bc)     
  
 
    [nd,nd]=size(K);
     fdof=[1:nd]';
     d=zeros(size(fdof));
     pdof=bc(:,1);
     dp=bc(:,2);
     fdof(pdof)=[];



     s=K(fdof,fdof)\(f(fdof)-K(fdof,pdof)*dp);
     d(pdof)=dp;
     d(fdof)=s;
