function [Wobj,Sens]=plast(xk, Storage,dbc, ELCOORD, Edof,ep, Nstep, LambdaInc,Target, Loaddofs)

% epnew    =Ynew(1);
% alphanew =Ynew(2);
% Dl       =Ynew(3);
 
Break.Disp=Target(1);  % Target displacement at plasticity initiation 
Break.Load=Target(2);  % Target load at plasticity initiation 
Break.Disp2=Target(3);
Break.Load2=Target(4);

Eo=ep(1,3);

nelm=length(Storage(1).stress);
ndof=length(Storage(1).Disp);
nISV=size(Storage(1).ISV,1);
dSigDy=zeros(nelm,nISV);
iJac=zeros(nISV,nISV,nelm);
gamma=zeros(nelm,nISV,Nstep);
JacNNm1=zeros(nISV,nISV,nelm);
Kt=zeros(ndof);
Fint=zeros(ndof,1);
pdof=dbc(:,1);    % Prescribed dofs
fdof=[1:ndof]';   % All dofs
fdof(pdof)=[];    % Free dofs
Sens=zeros(nelm,1); 
Wobj=0; 
Yold=zeros(size(Storage(1).ISV)) ;
Vo=ELCOORD(:,7).*ep(:,1); 

for i=1:Nstep                 % Calcluate the RHS for the \Varphi adjoint
      N     =Nstep-i+1;       % N={Nstep, Nstep-1, Nstep-2, ..... 1} when i={1, 2, 3, ..... Nstep} 
      Ynew  =Storage(N).ISV;
    
      aN    =Storage(N).Disp; 
      Etan  =Storage(N).Etan;
      stress=Storage(N).stress;
          
      if N>1          
         Yold=Storage(N-1).ISV;
      else
         Yold=Yold*0;  % Y is intially zero and it does not exist in the storage
      end            
      

      Kt=0*Kt;
      RHS=0*aN; 
      
      DeltaN=aN(Loaddofs(find(max(abs(aN(Loaddofs)))))); % The displacement is controlled in the dof with max displacement

      if abs(min(aN))<=abs(Break.Disp)     % Identify target response
           Fn=Break.Load*abs(min(aN))/abs(Break.Disp); 
      else
           Fn=(Break.Load2-Break.Load)*(abs(min(aN))-abs(Break.Disp))/(abs(Break.Disp2)-abs(Break.Disp))+Break.Load;              
      end
  
      Ap=aN;
      Ap(fdof)=0;   % Ap represents precibed displacements
      Fint=0*aN;            
      for elnr=1:nelm % aN is the last step
         t=Edof(elnr,:);
         fe=bar3gf(xk(elnr), ELCOORD(elnr,:),aN(t),stress(elnr),ep(elnr,:));             
         Fint(t) = Fint(t)+fe;
      end 
    
      Rn=aN(pdof)'*Fint(pdof)/DeltaN; 

      for elnr=1:nelm   
         t=Edof(elnr,:); 
         [Ke,dEpsda]=bar3ge(xk(elnr), ELCOORD(elnr,:),aN(t),stress(elnr),Eo,ep(elnr,:));          
         RHS(t)=RHS(t)+(Rn-Fn)*(1/DeltaN)*Ke*Ap(t)*LambdaInc(N);  

         [iJac(:,:,elnr),dCdeps,dSigDy(elnr,:),JacNNm1(:,:,elnr)]=UniStress_sensPlast(ELCOORD(elnr,:),aN(t),ep(elnr,:),Yold(:,elnr),Ynew(:,elnr));  
         [Ke,dEpsda]=bar3ge(xk(elnr), ELCOORD(elnr,:),aN(t),stress(elnr),Etan(elnr),ep(elnr,:));             
         Kt(t,t) = Kt(t,t)+Ke;   
        
         if i>1 
            RHS(t)=RHS(t)+dEpsda*dCdeps*iJac(:,:,elnr)'*(JacNNm1(:,:,elnr)'*gamma(elnr,:,i-1)'...
                -((Rn-Fn)*(1/DeltaN)*LambdaInc(N))*bar3gf_sens(xk(elnr), ELCOORD(elnr,:),aN(t),stress(elnr),ep(elnr,:),dSigDy(elnr,:))'*Ap(t) ...
                   ) ;            

         else % Load step N=Nstep (i=1)  
            RHS(t)=RHS(t)+dEpsda*dCdeps*iJac(:,:,elnr)'*(...
                  -((Rn-Fn)*(1/DeltaN)*LambdaInc(N))*bar3gf_sens(xk(elnr), ELCOORD(elnr,:),aN(t),stress(elnr),ep(elnr,:),dSigDy(elnr,:))'*Ap(t)) ;                           

         end                                          
      end
      
      Varphi=solveq(sparse(Kt),RHS,dbc); 
      Storage(i).Varphi=Varphi;            
      for elnr=1:nelm
         t=Edof(elnr,:);      
         Q=(-Varphi(t)+(Rn-Fn)*(1/DeltaN)*LambdaInc(N)*Ap(t))'*bar3gf_sens(xk(elnr), ELCOORD(elnr,:),aN(t),stress(elnr),ep(elnr,:),dSigDy(elnr,:));       
         if i>1 
            Q=Q-gamma(elnr,:,i-1)*JacNNm1(:,:,elnr);   
         end
         gamma(elnr,:,i)=Q*iJac(:,:,elnr);                  
      end
end

for N=1:Nstep 
       stress=Storage(N).stress;        
       Ynew=Storage(N).ISV;
       i=Nstep-N+1;
       Varphi=Storage(i).Varphi; 
       aN=Storage(N).Disp; 
       Ap=aN;
       Ap(fdof)=0; 

       LambdaInc(N)=LambdaInc(N);
       DeltaN=aN(Loaddofs(find(max(abs(aN(Loaddofs)))))); 

      if abs(min(aN))<=abs(Break.Disp)     
           Fn=Break.Load*abs(min(aN))/abs(Break.Disp); 
      else
           Fn=(Break.Load2-Break.Load)*(abs(min(aN))-abs(Break.Disp))/(abs(Break.Disp2)-abs(Break.Disp))+Break.Load;              
      end

       Fint=0*aN; 
       for elnr=1:nelm % aN is the last step
            t=Edof(elnr,:);
            fe=bar3gf(xk(elnr), ELCOORD(elnr,:),aN(t),stress(elnr),ep(elnr,:));             
            Fint(t) = Fint(t)+fe;
       end 
      


       Rn=aN(pdof)'*Fint(pdof)/DeltaN; 

       if N>1 
         Yold=Storage(N-1).ISV;
       else
         Yold=Yold*0;
       end    
       for elnr=1:nelm 
          t=Edof(elnr,:);         
          fe=(-Varphi(t)'+(Rn-Fn)*Ap(t)'*(1/DeltaN)*LambdaInc(N))*bar3gf_sens(xk(elnr),ELCOORD(elnr,:),aN(t),stress(elnr),ep(elnr,:)); 
          Sens(elnr)=Sens(elnr)+fe;  
       end 

       Wobj=Wobj+1/2*(Rn-Fn)^2*LambdaInc(N);  
end






   
