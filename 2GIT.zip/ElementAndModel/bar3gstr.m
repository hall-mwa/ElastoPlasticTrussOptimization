 function  [epsnew]=bar3gstr(elcoord,ed)

   
   Lo=elcoord(7);     
   X21Prime=elcoord(2)-elcoord(1)+ed(4)-ed(1);
   Y21Prime=elcoord(4)-elcoord(3)+ed(5)-ed(2);
   Z21Prime=elcoord(6)-elcoord(5)+ed(6)-ed(3);
      
   Ln=sqrt(X21Prime^2+Y21Prime^2+Z21Prime^2);
   epsnew=log(Ln/Lo);

