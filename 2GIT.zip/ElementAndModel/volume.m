 function  [Vol, Vol_sens]=volume(xk,Lengths,ep)
   
   Vol=0;
  
   for elnr=1:length(xk)   
      Vol=Vol+xk(elnr)*Lengths(elnr)*ep(elnr,1);
      Vol_sens(elnr)=Lengths(elnr)*ep(elnr,1);
   end



         







