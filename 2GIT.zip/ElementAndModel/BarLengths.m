 function  Lengths=BarLengths(ELCOORD)

  
for elnr=1:length(ELCOORD(:,1))   
      X21=ELCOORD(elnr,2)-ELCOORD(elnr,1);
      Y21=ELCOORD(elnr,4)-ELCOORD(elnr,3);
      Z21=ELCOORD(elnr,6)-ELCOORD(elnr,5);
      Lengths(elnr)=sqrt(X21^2+Y21^2+Z21^2);
end
         







