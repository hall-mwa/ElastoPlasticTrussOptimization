 function  [Ke,dEpsda]=bar3ge(ze,elcoord,ed,stress,Etan,ep)
%
%function  varargout=bar3ge(ze,ex,ey,ez,ed,stress,Etan,ep)
% Ke=bar3ge(ex,ey,ez,ed,stress,Etan,ep)
%----------------------------------------------------------------
% PURPOSE
%  Compute element stiffness matrix for three dimensional geometric
%  nonlinear bar element.
%
% INPUT:  ex = [x1 x2]
%         ey = [y1 y2]       
%         ez = [z1 z2]       element node coordinates         
%
%         ed=  [ux1 ux2 uy1 uy2 uz1 uz2]
%
%         stress             Normal Stress
%
%         Etan               (Algoritmic) Tangent stiffness         
%
%         ep = [A nu]        A: Undeformed cross section area
%                            nu: Poisson's ratio
%
%         stress             Normal stress
%
% OUTPUT: Ke :   stiffness matrix, dim(Ke)= 6 x 6
%----------------------------------------------------------------


   pen=ep(7);
   delta0=ep(8);
   Ao=ep(1)*ze; 
   
   nu=ep(2);
            
   
   Lo=elcoord(7);
   
   
   alphao=Lo/2;
   
 
   
   X21Prime=elcoord(2)-elcoord(1)+ed(4)-ed(1);
   Y21Prime=elcoord(4)-elcoord(3)+ed(5)-ed(2);
   Z21Prime=elcoord(6)-elcoord(5)+ed(6)-ed(3);
  
   Ln=sqrt(X21Prime^2+Y21Prime^2+Z21Prime^2);


   cxPrime=[-X21Prime  -Y21Prime  -Z21Prime X21Prime  Y21Prime  Z21Prime ]';
   
   Lam=Lo/Ln;
   An=Lam^(2*nu)*Ao;
   
   
   Amat=[ 1     0     0    -1     0     0;
          0     1     0     0    -1     0;
          0     0     1     0     0    -1;
         -1     0     0     1     0     0;
          0    -1     0     0     1     0;
          0     0    -1     0     0     1];
   
   Ke=(Etan*An*Lam^3/(8*alphao^3)-(1+2*nu)*stress*An*Lam^3/(8*alphao^3))*(cxPrime*cxPrime');
   
   Ke=Ke+stress*An*Lam/alphao*Amat/2;    

   if nargout==2
      dEpsda=cxPrime/Ln^2;
   end
  
