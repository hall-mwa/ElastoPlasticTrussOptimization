
 function fe=bar3gf_sens(ze, elcoord,ed,stress,ep,dSigdY)
% fe=bar3gf(ex,ey,ez,ed,stress,ep)
%----------------------------------------------------------------
% PURPOSE
%  Compute element stiffness matrix for three dimensional geometric
%  nonlinear bar element.
%
% INPUT:  ex = [x1 x2]
%         ey = [y1 y2]       
%         ez = [z1 z2]       element node coordinates         
%
%         ed=  [ux1 ux2 uy1 uy2 uz1 uz2]
%
%         ep = [E A nu]      E:  (Algoritmic) Tangent modulus
%                            A: Undeformed cross section area
%                            nu: Poisson's ratio
%
%         stress             Normal stress
%
% OUTPUT: fe :   internal force vector, dim(fe)= 6 x 1
%----------------------------------------------------------------


   
   
   Ao=ep(1); 
   nu=ep(2);
   pen=ep(7);
   delta0=ep(8);
   
   X21=elcoord(2)-elcoord(1);
   Y21=elcoord(4)-elcoord(3);
   Z21=elcoord(6)-elcoord(5);
   Lo=sqrt(X21^2+Y21^2+Z21^2);
   alphao=Lo/2;


   
   X21Prime=X21+ed(4)-ed(1);
   Y21Prime=Y21+ed(5)-ed(2);
   Z21Prime=Z21+ed(6)-ed(3);
   Ln=sqrt(X21Prime^2+Y21Prime^2+Z21Prime^2);

   cxPrime=[-X21Prime  -Y21Prime  -Z21Prime X21Prime  Y21Prime  Z21Prime ]';

   Lam=Lo/Ln;

   if nargin==6
     fe=Lam^(1+2*nu)*Ao*ze/(2*alphao)*cxPrime*dSigdY;
   end
   if nargin==5
      fe=Lam^(1+2*nu)*Ao*stress/(2*alphao)*cxPrime;
   end




