
 function fe=bar3gf(ze, elcoord,ed,stress,ep)
% fe=bar3gf(ex,ey,ez,ed,stress,ep)
%----------------------------------------------------------------
% PURPOSE
%  Compute element stiffness matrix for three dimensional geometric
%  nonlinear bar element.
%
% INPUT:  ex = [x1 x2]
%         ey = [y1 y2]       
%         ez = [z1 z2]       element node coordinates         
%
%         ed=  [ux1 ux2 uy1 uy2 uz1 uz2]
%
%         ep = [E A nu]      E:  (Algoritmic) Tangent modulus
%                            A: Undeformed cross section area
%                            nu: Poisson's ratio
%
%         stress             Normal stress
%
% OUTPUT: fe :   internal force vector, dim(fe)= 6 x 1
%----------------------------------------------------------------

% LAST MODIFIED: M Wallin    2021-10-18
% Copyright (c)  Division of Structural Mechanics and
%                Department of Solid Mechanics.
%                Lund Institute of Technology
%----------------------------------------------------------------

   
   
   pen=ep(7);
   delta0=ep(8);
   

   Ao=ep(1)*ze; 

   
   nu=ep(2);

  
   
   
   Lo=elcoord(7);
   alphao=Lo/2;

 
   
   X21Prime=elcoord(2)-elcoord(1)+ed(4)-ed(1);
   Y21Prime=elcoord(4)-elcoord(3)+ed(5)-ed(2);
   Z21Prime=elcoord(6)-elcoord(5)+ed(6)-ed(3);   
   
   
   Ln=sqrt(X21Prime^2+Y21Prime^2+Z21Prime^2);

 
   cxPrime=[-X21Prime  -Y21Prime  -Z21Prime X21Prime  Y21Prime  Z21Prime ]';
 
   Lam=Lo/Ln;

   fe=Lam^(1+2*nu)*Ao*stress/(2*alphao)*cxPrime;



 
%--------------------------end--------------------------------
