function         [stress,Ynew,Etan, problem]=UniStressPlast(ep,Yold,epsnew)
%function         
%----------------------------------------------------------------
% PURPOSE
%  Compute stress an elasto-plastic state update.
%
% INPUT:  
%         Yold = state variables from last accepted equlibrium state
%         Ynew = Updated state variables
%
%         ep = [Ao nu E K S]     E:  Youngs modulus
%                                A:  Undeformed cross section area
%                                nu: Poisson's ratio
%                                K:  Hardening modulus
%                                S:  Damage modulus
%         stress             Normal stress
%
%----------------------------------------------------------------

   problem=0;  
   Eo=ep(3); sigyo=ep(4); K=ep(5);
   
   


   epold    =Yold(1);
   alphaold =Yold(2);

   TrialStress=Eo*(epsnew-epold); 

   if abs(TrialStress)-sigyo-K*alphaold>0
      Ynew=Yold; % Initial guess for internal variables
      Res=[1 1 1]';
      iter=0;
      while ((norm(Res)>1e-12) & (problem==0))
            iter=iter+1;
            epnew    =Ynew(1);
            alphanew =Ynew(2);
            
            Dl       =Ynew(3);

            Res = [epnew - epold - Dl * abs(Eo * (-epsnew + epnew)) / Eo / (epsnew - epnew) 
                   alphanew - alphaold - Dl 
                   abs(Eo * (-epsnew + epnew)) - K * alphanew - sigyo]';


           % Res = [epnew - epold - Dl * abs(Eo * (1 - Dnew) * (epsnew - epnew)) / Eo / (1 - Dnew) ^ 2 / (epsnew - epnew) ...
           %        alphanew - alphaold - Dl ...
           %        Dnew - Dold - (Eo * (epsnew - epnew) ^ 2 / S * Dl) / 0.2e1 ...
           %        abs(Eo * (1 - Dnew) * (epsnew - epnew)) / (1 - Dnew) - K * alphanew - sigyo]


            Jac = [1 - Dl * sign(Eo * (-epsnew + epnew)) / (epsnew - epnew) - Dl * abs(Eo * (-epsnew + epnew)) / Eo / (epsnew - epnew) ^ 2 0 -abs(Eo * (-epsnew + epnew)) / Eo / (epsnew - epnew); 
                   0 1 -1; 
                   Eo * sign(Eo * (-epsnew + epnew)) -K 0;];

           % Jac = [1 + Dl / (1 - Dnew) * sign(Eo * (1 - Dnew) * (epsnew - epnew)) / (epsnew - epnew) - ...
           %       Dl * abs(Eo * (1 - Dnew) * (epsnew - epnew)) / Eo / (1 - Dnew) ^ 2 / (epsnew - epnew) ^ 2 ...
           %       0 Dl * sign(Eo * (1 - Dnew) * (epsnew - epnew)) / (1 - Dnew) ^ 2 - ...
           %       2 * Dl * abs(Eo * (1 - Dnew) * (epsnew - epnew)) / Eo / (1 - Dnew) ^ 3 / (epsnew - epnew) ...
           %      -abs(Eo * (1 - Dnew) * (epsnew - epnew)) / Eo / (1 - Dnew) ^ 2 / (epsnew - epnew); ...
           %       0 1 0 -1; Eo * (epsnew - epnew) / S * Dl 0 1 -(Eo * (epsnew - epnew) ^ 2 / S) / 0.2e1; ...
           %      -Eo * sign(Eo * (1 - Dnew) * (epsnew - epnew)) ... 
           %      -K -Eo * (epsnew - epnew) * sign(Eo * (1 - Dnew) * (epsnew - epnew)) / (1 - Dnew) + ...
           %      abs(Eo * (1 - Dnew) * (epsnew - epnew)) / (1 - Dnew) ^ 2 0;];
            
             Ynew=Ynew-Jac\Res';  

             if (iter>20)
                problem=1;
                disp('Local platicity loop is diverging')
             end
            
      end


      DRDeps = [Dl * sign(Eo * (-epsnew + epnew)) / (epsnew - epnew) + Dl * abs(Eo * (-epsnew + epnew)) / Eo / (epsnew - epnew) ^ 2 
                0 
               -Eo * sign(Eo * (-epsnew + epnew))]';



      DYDeps=-Jac\DRDeps';
      epnew =Ynew(1);
      Dl  =Ynew(3);
      stress=Eo*(epsnew - epnew);      
      Etan  =Eo*(1-DYDeps(1)); % Algorithmic tangent stiffness modulus
   else % Elastic response
      stress=TrialStress;
      Ynew=Yold;
      Ynew(3)=0;
      Etan=Eo;
   end


  

