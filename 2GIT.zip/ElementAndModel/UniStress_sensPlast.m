function         [OUT1,OUT2,OUT3,OUT4]=UniStress_sens(elcoord,ed,ep,Yold, Ynew)

%----------------------------------------------------------------
% PURPOSE
%  Compute stress an elasto-plastic state update.
%
% INPUT:  ex = [x1 x2]
%         ey = [y1 y2]       
%         ez = [z1 z2]       element node coordinates         
%keyboard

%         ed = [ux1 ux2 uy1 uy2 uz1 uz2]
%
%         Yold = state variables from last accepted equlibrium state
%         Ynew = Updated state variables
%
%         ep = [Ao nu E K]     E:  Youngs modulus
%                              A:  Undeformed cross section area
%                              nu: Poisson's ratio
%                              K:  Hardening modulus
%         stress               stress
%
% OUTPUT: fe :   internal force vector, dim(fe)= 6 x 1
%----------------------------------------------------------------


   Eo=ep(3); sigyo=ep(4); K=ep(5); 
   

   epold    =Yold(1);
   alphaold =Yold(2);
   epnew    =Ynew(1);  
   Dl       =Ynew(3);

   Lo=elcoord(7); %Volume/Area
     
   X21Prime=elcoord(2)-elcoord(1)+ed(4)-ed(1);
   Y21Prime=elcoord(4)-elcoord(3)+ed(5)-ed(2);
   Z21Prime=elcoord(6)-elcoord(5)+ed(6)-ed(3);   
 
   Ln=sqrt(X21Prime^2+Y21Prime^2+Z21Prime^2);
   epsnew=log(Ln/Lo);

    if (Ynew(3)>0) % Plastic response         
              
       Jac = [1 - Dl * sign(Eo * (-epsnew + epnew)) / (epsnew - epnew) - Dl * abs(Eo * (-epsnew + epnew)) / Eo / (epsnew - epnew) ^ 2 0 -abs(Eo * (-epsnew + epnew)) / Eo / (epsnew - epnew); 
              0 1 -1; 
              Eo * sign(Eo * (-epsnew + epnew)) -K 0;];
       iJac=inv(Jac);

       DRDeps = [Dl * sign(Eo * (-epsnew + epnew)) / (epsnew - epnew) + Dl * abs(Eo * (-epsnew + epnew)) / Eo / (epsnew - epnew) ^ 2 
                0 
               -Eo * sign(Eo * (-epsnew + epnew))]';

       OUT1=iJac;
       OUT2=DRDeps; 
   else           % Elastic response
       OUT1=[1 0 0 ; 0 1  0; 0 0 1];   
       OUT2=zeros(1,3);
   end
   OUT3=[-Eo 0  0;];  
   OUT4= [-1 0 0; 0 -1  0; 0 0 0;];


